library(ggplot2)

plot(schools$School, schools$Middling)

ggplot(schools[schools$School == 'A', ], aes(x=Middling)) + geom_histogram(binwidth = .5)


ggplot(bySchools, aes(x=bySchools[1,])) +
  geom_histogram(fill="white")

bySchools
Totals = rowSums(bySchools[,2:7])
bySchools/Totals




Aschool = schools[schools$School == 'A', ]
AschoolTotals = colSums(Aschool[,3:8 ])
AschoolTotals/sum(AschoolTotals)
signif(AschoolTotals/sum(AschoolTotals)*100, digits = 3)

print(AschoolTotals/sum(AschoolTotals))

schoolPercent = function(df, school_code) {
  sc = df[df[ ,1] == school_code, ]
  return(rbind(Total = colSums(sc[,3:8 ]), Percent = signif(colSums(sc[,3:8 ])/sum(colSums(sc[,3:8 ]))*100, digits = 3)))
}

A = schoolPercent(schools, 'A')
B = schoolPercent(schools, 'B')
C = schoolPercent(schools, 'C')
D = schoolPercent(schools, 'D')
E = schoolPercent(schools, 'E')

A
B
C
D
E

plot(A[1, 1:6])
hist(A[1, 1:6])


schoolPercentV2 = function(df, col_num, school_code) {
  sc = df[df[ ,col_num] == school_code, ]
  return(rbind(Total = colSums(sc[,3:8 ]), Percent = signif(colSums(sc[,3:8 ])/sum(colSums(sc[,3:8 ]))*100, digits = 3)))
}

A
cast(schools, Section ~ School )


grid.arrange(histPlot, histPlot.v2, ncol=2)

a = ggplot(schools, aes(School, Completed)) +
  geom_col()
#geom_col(aes(fill = Section))

b = ggplot(schools, aes(School, VeryBehind)) +
  geom_col()
#geom_col(aes(fill = Section))

grid.arrange(a,b, ncol=2)

# nope
Aschool = schools[schools$School == 'A', ]
Dschool = schools[schools$School == 'D', ]

scale(Aschool$Middling)
scale(Dschool$Middling)

ScaledSchool = NewSchoolsSec[,-8]

for (i in 3:length(ScaledSchool)) {
  ScaledSchool[,i] = scale(ScaledSchool[,i])
}




for (i in 1:length(TheListCounts)) {
  section.hist = rbind(section.hist, TheListCounts[[i]])
}

section.hist.per = data.frame()
for (i in 1:length(TheListPer)) {
  section.hist.per = rbind(section.hist.per, TheListPer[[i]])
}