#Read in data
data <- read.csv("/Users/snlaun/Downloads/collegescorecard-3.csv",na.string=c(""))
data
View(data)
#Plot with axis titles
plot(data$federal_loan_rate,data$admission_rate.overall,main="Federal Loan Rate & Admission", xlab="Federal Loan Rate",ylab="Federal Loan Rate")
plot(data$ownership,data$federal_loan_rate,main="Ownership vs. Financial Aid",xlab="Ownership",ylab="Federal Loan Rate")
plot(data$federal_loan_rate,data$sat_scores.midpoint.math,main="Loan Rates vs SAT Score",xlab="Loan Rate",ylab="SAT Score (MATH)")
abline(lm(data$sat_scores.midpoint.math~data$federal_loan_rate), col = 'red')
plot(data$federal_loan_rate,data$sat_scores.midpoint.critical_reading,main="Loan Rates vs SAT Score",xlab="Loan Rate",ylab="SAT Score (Reading)")
abline(lm(data$sat_scores.midpoint.critical_reading~data$federal_loan_rate), col = 'red')
plot(data$federal_loan_rate,data$sat_scores.midpoint.writing,main="Loan Rates vs SAT Score",xlab="Loan Rate",ylab="SAT Score (Writing)")
abline(lm(data$sat_scores.midpoint.writing~data$federal_loan_rate), col = 'red')
plot(data$federal_loan_rate,data$sat_scores.midpoint.math,main="Loan Rates vs SAT Score",xlab="Loan Rate",ylab="SAT Score (MATH)")
abline(lm(data$sat_scores.midpoint.math~data$federal_loan_rate), col = 'red')
