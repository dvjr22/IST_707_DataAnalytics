## Set up environment -----
library(caret)
library(e1071)
library(rpart)
library(rpart.plot)
library(rattle)
library(factoextra)
library(slam)
library(cluster)
library(amap)
library(ggplot2)
library(dplyr)
library(DescTools)
library(purrr)
library(tidyverse)
library(ggplot2)
library(arules)
library(arulesViz)
library(corrplot)
library(randomForest)
## Data reformatting ----
scorecard <- read.csv("scorecard-3.csv", stringsAsFactors = FALSE)
## str: data types
str(scorecard)
scorecard$state <- factor(scorecard$state)
str(scorecard)
# ownership, carnegie basic & carnegie.ugrd
scorecard$ownership <- factor(scorecard$ownership)
scorecard$carnegie.basic <- factor(scorecard$carnegie.basic)
scorecard$carnegie.ugrd <- factor(scorecard$carnegie.ugrd)

#convert characters to numeric. force some nulls
scorecard[,c(7:9,32:38)] <- as.data.frame(apply(scorecard[,c(7:9,32:39)], 2, as.numeric))
scorecard$enrollment.all <- as.numeric(scorecard$enrollment.all)
warnings()

str(scorecard)

 ## null values?
# look for numbers stored as characters
#create function to count number of null values in a vector
null.count <- function(variable) {
  return(length(which(is.na(variable))))
}

# apply function to each column in dataframe
apply(scorecard, 2, null.count)

# the last row, kennesaw state has all null values for after grad variables . 

## give colleges unique names (Emmanuel college occurs twice)
scorecard$name <- ifelse(scorecard$name == "Emmanuel College" & scorecard$state=="GA", "Emmanuel College (GA)", 
                         ifelse(scorecard$name == "Emmanuel College" & scorecard$state == "MA", "Emmanuel College (MA)", scorecard$name))

## Explore attributes ----
str(scorecard)
table(scorecard$state)
table(scorecard$ownership)
table(scorecard$carnegie.basic) # not many engineering schools. some health, faith, business, art
table(scorecard$carnegie.ugrd) 
hist(scorecard$admission_rate.overall) # most are over 50%. skewed/tail to left
hist(scorecard$size)  #skewed/tail to right, but it looks like there are some outliers
boxplot(scorecard$size)  # lots of outliers, but still lots of skew
hist(scorecard$enrollment.all)
plot(scorecard$size, scorecard$enrollment.all) # ok so enrollment and size are directly related, but size is bigger than enrollment
hist(scorecard$avg_net_price)  # skewed/tail to right, most are lower, less than $20,000
hist(scorecard$title_iv)  #number of title iv students
scorecard$percent.iv <- scorecard$title_iv/scorecard$size
hist(scorecard$percent.iv)
plot(scorecard$percent.iv, scorecard$attendance.academic_year) # parabolic relationship
plot(scorecard$federal_loan_rate, scorecard$attendance.academic_year)  #very interesting relationship
plot(scorecard$federal_loan_rate, scorecard$admission_rate.overall) # not much of a relationship after a certain point
plot(scorecard$federal_loan_rate, scorecard$retention_rate.four_year.full_time)
plot(scorecard$federal_loan_rate, scorecard$completion_rate_4yr_150nt)
plot(scorecard$students_with_any_loan, scorecard$attendance.academic_year)
plot(scorecard$students_with_any_loan, scorecard$retention_rate.four_year.full_time)
hist(scorecard$students_with_any_loan) # so everyone has loans

# financial aid & carnegie classification
boxplot(federal_loan_rate ~ carnegie.basic, data=scorecard) # very interesting!
ggplot(data=scorecard, aes(x=carnegie.basic, y=federal_loan_rate)) + geom_boxplot() + theme(axis.text.x  = element_text(angle=90, vjust=0.5, size = 14)) + ylab("Federal Loan Rate")
boxplot(federal_loan_rate ~ carnegie.ugrd, data=scorecard) # very interesting!
ggplot(data=scorecard, aes(x=carnegie.ugrd, y=federal_loan_rate)) + geom_boxplot() + theme(axis.text.x  = element_text(angle=90, vjust=0.5)) + ylab("Federal Loan")

# financial aid & ownership
ggplot(data=scorecard, aes(x=ownership, y=federal_loan_rate)) + geom_boxplot() + theme(axis.text.x  = element_text(angle=90, vjust=0.5)) 
ggplot(data=scorecard, aes(x=ownership, y=pell_grant_rate)) + geom_boxplot() + theme(axis.text.x  = element_text(angle=90, vjust=0.5)) 
ggplot(data=scorecard, aes(x=ownership, y=retention_rate.four_year.full_time)) + geom_boxplot() + theme(axis.text.x  = element_text(angle=90, vjust=0.5)) 
ggplot(data=scorecard, aes(x=ownership, y=completion_rate_4yr_150nt)) + geom_boxplot() + theme(axis.text.x  = element_text(angle=90, vjust=0.5)) 

# grouped boxplots
box <- scorecard %>% select(ownership, federal_loan_rate, pell_grant_rate, retention_rate.four_year.full_time, completion_rate_4yr_150nt)
library(reshape2)
boxm <- box %>% gather(financial.aid, rate, federal_loan_rate:pell_grant_rate)
boxm <- boxm %>% gather(success.measure, success.rate, retention_rate.four_year.full_time:completion_rate_4yr_150nt)
ggplot(data=boxm, aes(x=ownership, y=success.rate)) + geom_boxplot(aes(fill=success.measure)) + 
  theme(axis.text.x  = element_text(size=14), axis.text.y = element_text(size=14), legend.text = element_text(size=14)) + 
  ggtitle("Ownership & Student Success While in College") + 
  scale_fill_discrete(name="Success Measure", breaks=c("completion_rate_4yr_150nt", "retention_rate.four_year.full_time"), labels=c("4yr Graduation Rate", "Retention Rate"))
ggplot(data=boxm, aes(x=ownership, y=rate)) + geom_boxplot(aes(fill=financial.aid)) + 
  theme(axis.text.x  = element_text(size=14), axis.text.y = element_text(size=14), legend.text = element_text(size=14)) + 
  ggtitle("Ownership & Financial Aid") + 
  scale_fill_discrete(name="Financial Aid Type", breaks=c("federal_loan_rate", "pell_grant_rate"), labels=c("Federal Loan Rate", "Pell Grant Rate"))
                      
str(boxm)
library(ggplot2)
library(dplyr)
library(DescTools)
scorecard %>% filter(name %like% "%Syracuse%") %>% select(enrollment.all, size, attendance.academic_year)
# Bulk viz
scorecard %>% 
  keep(is.numeric) %>%
  gather() %>% 
  ggplot(aes(value)) + facet_wrap(~ key, scales="free") + geom_histogram()

scorecard %>% 
  keep(is.numeric) %>%
  gather() %>% 
  ggplot(aes(value)) + facet_wrap(~ key, scales="free") + geom_density()



## Analysis: How is financial aid related to student success during school, as measured by retention and graduation?-----
library(purrr)
library(tidyverse)
library(ggplot2)
str(scorecard)
# create focused dataset----
during <-scorecard %>%
  select(name, size, attendance.academic_year, avg_net_price, pell_grant_rate, federal_loan_rate, retention_rate.four_year.full_time, completion_rate_4yr_150nt)

str(during)
# visual relationship between variables of interest
pairs(during)
abc <- during %>% select(attendance.academic_year, pell_grant_rate, federal_loan_rate, retention_rate.four_year.full_time, completion_rate_4yr_150nt)
pairs(abc)

# retention & federal loans
plot(during$federal_loan_rate, during$retention_rate.four_year.full_time, col="blue", main = "Federal Loan Rate & Retention", xlab="Federal Loan Rate", ylab="Retention Rate") 
abline(lm(during$federal_loan_rate ~ during$retention_rate.four_year.full_time))  #strong negative relationship!!!

# retention & pell_grant rate
plot(during$pell_grant_rate, during$retention_rate.four_year.full_time, col="blue", main = "Pell Grant Rate & Retention", xlab="Pell Grant Rate", ylab="Retention Rate")
abline(lm(during$pell_grant_rate ~ during$retention_rate.four_year.full_time))  # strong negative relationship!

# graduation & federal loans
plot(during$federal_loan_rate, during$completion_rate_4yr_150nt, col="red", main = "Federal Loan Rate & Graduation Rate", xlab="Federal Loan Rate", ylab="4yr Graduation Rate")
abline(lm(during$federal_loan_rate ~ during$completion_rate_4yr_150nt)) # less strong

# graduation & pell_grant
plot(during$pell_grant_rate, during$completion_rate_4yr_150nt, col="red", main = "Pell Grant Rate & Graduation Rate", xlab="Pell Grant Rate", ylab="4yr Graduation Rate")
abline(lm(during$pell_grant_rate ~ during$completion_rate_4yr_150nt))


## Clustering -----
# dendrogram
library(factoextra)
library(slam)
library(cluster)
library(amap)

during <-scorecard %>%
  select(name, carnegie.basic, carnegie.ugrd, state, size, attendance.academic_year, avg_net_price, pell_grant_rate, federal_loan_rate, retention_rate.four_year.full_time, completion_rate_4yr_150nt)
# rownames(during) <- scorecard$name
str(during)

# create distance measures for attributes 5-11
distance.euc <- get_dist(during[,5:11], method = "euclidean")
distance.euc
fviz_dist(distance.euc) # a lot goin on there

# create distance matrix using Euclidean measure of distance
distance.man <- get_dist(during[,5:11], method = "manhattan")
distance.man

# Visualize the distance matrix
fviz_dist(distance.man)

# cosine similarity
during.stm<-as.simple_triplet_matrix(during[,5:11])
cosine_dist_mat <- 1-crossprod_simple_triplet_matrix(during.stm)/sqrt(col_sums(during.stm^2) %*% t(col_sums(during.stm^2)))
cosine_dist_mat
cos_sim_matrix <- 1-(cosine_dist_mat)
cos_sim_matrix
heatmap(cos_sim_matrix)


# generate distance matrix using euclidean method
distance.euc <- get_dist(during[,5:11], method = "euclidean")
# experiment with clustering methods
e.comp <- agnes(distance.euc, method = "complete")
e.comp$ac 
plot(e.comp) # agglom coeffic of .9735.
e.single <- agnes(distance.euc, method = "single") 
plot(e.single) 
e.single$ac # agglomerative coeffic of .858
e.ward <- agnes(distance.euc, method = "ward")
plot(e.ward) 
e.ward$height
e.ward$ac #ac of .9958!
e.avg <- agnes(distance.euc, method = "average")
plot(e.avg) 
e.avg$ac #ac of .9524
e.centroid <- hclust(distance.euc, method = "centroid")
plot(e.centroid) 

# generate distance matrix using manhattan method
distance.man <- get_dist(during[,5:11], method = "manhattan")
# experiment with clustering methods
m.comp <- agnes(distance.man, method = "complete")
plot(m.comp) # agglom coeffic of .98
m.comp$ac
m.single <- agnes(distance.man, method = "single")
m.single$ac #.875
plot(m.single) 
m.ward <- agnes(distance.man, method = "ward")
m.ward$ac #.9959
plot(m.ward) 
m.avg <- agnes(distance.man, method = "average")
m.avg$ac #.956
plot(m.avg) 
m.centroid <- hclust(distance.man, method = "centroid")
plot(m.centroid) 

# compare top 2 clusters with tanglegram
library(dendextend)
hc1 <- hclust(distance.euc, method = "complete")
hc2 <- hclust(distance.euc, method = "ward.D2")
dend1 <- as.dendrogram(hc1)
dend2 <- as.dendrogram(hc2)
tanglegram(dend1, dend2)  # this is cool clusters pretty much stick together, with some exceptions

# ideal number of clusters
d2 <- during[,5:11]
rownames(d2) <- during$name
fviz_nbclust(d2, FUN=hcut, method="silhouette")  # suggests 2 clusters, which isn't super helpful
gap_stat <- clusGap(d2, FUN=hcut, nstart=25, K.max=10, B=50) # suggests 4, with 5 being a close second
fviz_gap_stat(gap_stat)
?fviz_nbclust

# experiment with number of clusters: centroid
plot(e.centroid)
rect.hclust(e.centroid, k=4) # tiny clusters on the left
rect.hclust(e.centroid, k=6) # tiny little clusters on the left
rect.hclust(e.centroid, k=3)
# this is not great, which suggests that using kmeans isn't going to be fantastic either. 

# partitional clustering
# euclidean
euc3 <- Kmeans(during[,5:11], 3, method = "euclidean", iter.max = 500)
euc3$withinss
sum(296027177, 47366105, 266661625) #610,054,907
euc4 <- Kmeans(during[,5:11], 4, method="euclidean", iter.max=500)
euc4$withinss
sum(36709702, 86053559, 277685156, 21687382) #422,135,799
euc6 <- Kmeans(during[,5:11], 6, method="euclidean", iter.max=500)
euc6$withinss
sum(11365677, 34486287, 11035352, 261373841, 19540438, 111616372) #449,417,967
plot(euc6)

# manhattan
man3 <- Kmeans(during[,5:11], 3, method="manhattan", iter.max=500)
man3$withinss
sum(215006726,608979753,287650612) #1,111,637,091
man4 <- Kmeans(during[,5:11], 4, method="manhattan", iter.max=500)
man4$withinss
sum(498205911, 185857658,  41649998,  57608551) #783,322,118
man6 <- Kmeans(during[,5:11], 6, method="manhattan", iter.max=500)
man6$withinss 
sum(136521690, 55404422, 321573994, 140275480, 51153601, 32794094) #737,723,281
man8 <- Kmeans(during[,5:11], 8, method="manhattan", iter.max=500)
man8$withinss 
sum(7488820, 32794094, 169585305, 58068259, 127847639, 17426330, 273272046, 53581485) #740,063,978




# plot k=4, lowest SSE
clusplot(during[,5:11], euc4$cluster, color=TRUE, labels = 2, lines = 0)


# number of clusters: ward
plot(m.ward)
rect.hclust(m.ward, k=3) #groups are uneven, too general
rect.hclust(m.ward, k=4) #pretty good, one huge group
rect.hclust(m.ward, k=5) #pretty good. even groups, breaks up huge group
rect.hclust(m.ward, k=6) # still pretty good, but groups are less even, probably don't need 6 groups

# try both 4 & 5 for ward

plot(during$retention_rate.four_year.full_time ~ during$completion_rate_4yr_150nt)
View(during)

# assign clusters
ewrd.d <- hclust(distance.euc, method="ward.D2")
sub_grp4 <- cutree(ewrd.d, k=4)
sub_grp5 <- cutree(ewrd.d, k=5)
during.clust <- during %>%
  mutate(clus4 = sub_grp4) %>%
  mutate(clus5 = sub_grp5)

# visualize clusters
fviz_cluster(list(data=d2, cluster=sub_grp4))
fviz_cluster(list(data=d2, cluster=sub_grp5))
?fviz_cluster

# Understand clusters
boxplot(federal_loan_rate~clus4, data=during.clust)
boxplot(pell_grant_rate~clus4, data=during.clust)  # not a huge difference here
boxplot(retention_rate.four_year.full_time~clus4, data=during.clust)
boxplot(completion_rate_4yr_150nt~clus4, data=during.clust)
boxplot(avg_net_price ~ clus4, data=during.clust)
boxplot(attendance.academic_year ~ clus4, data=during.clust)  

summary4 <- during.clust %>%
  group_by(clus4) %>%
  summarise_all(.funs=mean) %>%
  select(-name, -carnegie.basic, -carnegie.ugrd, -state)
View(summary4)

summary5 <- during.clust %>%
  group_by(clus5) %>%
  summarise_all(.funs=mean) %>%
  select(-name, -carnegie.basic, -carnegie.ugrd, -state)
View(summary5)

compare45 <- rbind(summary4, summary5)
compare45 <- compare45[,c(1,9,2:8)]
View(compare45)
# using 4 clusters seems to divide them more clearly. Adding another cluster muddies the water. Stick to 4 clusters
during <- during %>%
  mutate(cluster=sub_grp4)

during$cluster <- ifelse(during$cluster==1, "Entry Level", 
                         ifelse(during$cluster==2, "Stable", 
                         ifelse(during$cluster==3, "Reachers", 
                         ifelse(during$cluster==4, "Privileged", "ERROR"))))

during$cluster <- factor(during$cluster)
View(during)

# visualize with labels
fviz_cluster(list(data=d2, cluster=sub_grp4, legend(breaks=c(1,2,3,4), labels=c("Entry Level", "Stable", "Reachers", "Privileged")))) + scale_fill_discrete(name="Cluster", breaks=c(1,2,3,4), labels=c("Entry Level", "Stable", "Reachers", "Priveleged"))

# clean up environment
rm(compare45, cos_sim_matrix, cosine_dist_mat, d2, dend1, dend2, during.clust, during.clust2, e.avg, e.centroid, e.comp, e.single, e.ward, gap_stat, hc1, hc2, m.avg, m.centroid, m.comp, m.single, m.ward, mwrd.d, summary4, summary5, distance.man, sub_grp4, sub_grp5)
rm(euc3, euc4, euc6, man3, man4, man6, man8)
# summarize clusters
cluster.means <- during %>%
  select(-name, -carnegie.basic, -carnegie.ugrd, -state) %>%
  group_by(cluster) %>%
  summarise_all(.funs=mean)
View(cluster.means)

## ON AVERAGE:
#Cluster 4: lowest financial aid (20% pg avg, 44.7% fed loan avg), highest retention & completion (89%, 78%), highest price(59k/30k). ALL private schools. #Privileged
#Cluster 3: highest financial aid (38% pg avg, 66.7% fed loan avg), high retention, low completion (72%, 52%), high price (40k/21k) Mostly private schools. #Reachers
#Cluster 2: low financial aid (31% apg avg, 44.8% fed loan avg), 2nd highest retention & completion (85%, 65%), low price (24k/16k). Mostly state schools #Stable
#Cluster 1: high financial aid (40% pg avg, 54% fed loan avg), lowest retention & completion (70%, 42%), lowest price (21k/13k) Mix of public & private #Entry

during <- during %>%
  left_join(select(scorecard, ownership, name))
  
cluster.cb.count <- during %>%
  select(cluster, carnegie.basic) %>%
  group_by(cluster, carnegie.basic) %>%
  summarise(total=n()) %>%
  spread(cluster, total)
View(cluster.cb.count)  

#write.csv(during, "during.csv", row.names = FALSE)

# association rules mining ----
library(arules)
library(arulesViz)

          # if clusters are not in during dataframe, use this to add them: 
          #distance.euc <- get_dist(during[,5:11], method = "euclidean")
          #e.ward <- agnes(distance.euc, method = "ward")
          #ewrd.d <- hclust(distance.euc, method="ward.D2")
          #sub_grp4 <- cutree(ewrd.d, k=4)
          #during <- during %>% mutate(cluster=sub_grp4)
          #during$cluster <- ifelse(during$cluster==1, "Entry Level", 
          #                         ifelse(during$cluster==2, "Stable", 
          #                         ifelse(during$cluster==3, "Reachers", 
          #                         ifelse(during$cluster==4, "Privileged", "ERROR"))))
          # during$cluster <- factor(during$cluster)

str(during)
# prepare dataset for arules
discretize <- function(var) {
  return(cut(var, breaks=3, labels=c("low", "med", "high")))
}
d.disc <- as.data.frame(apply(during[,5:11], 2, discretize))
d.disc <- cbind(during[,c(2:4, 12:13)], d.disc)

d.disc.trans <- as(d.disc, "transactions")
itemFrequencyPlot(d.disc.trans, topN=20, type="absolute")


# arules mining
rules <- apriori(d.disc, parameter = list(supp = 0.2, conf = 0.9, minlen = 2))
summary(rules)
# max lift is 2.275, max support is .54

# highest confidence rules
rules.c<- sort(rules, decreasing = TRUE, by = "confidence")
arules::inspect(rules.c[1:10])
# expensive colleges get lower amounts of students with pell grants

# highest support rules
rules.s<- sort(rules, decreasing = TRUE, by = "support")
arules::inspect(rules.s[1:10])
# public colleges have low attendance cost. private nonprofit have small schools.

# highest lift
rules.l<- sort(rules, decreasing = TRUE, by = "lift")
arules::inspect(rules.l[1:10])
# low cost with laons w/ public [4]

plot(rules,method="graph", engine='interactive', shading=NA)
# too much going on to see 

# LHS: Federal loan rate = high
rules2 <- apriori(d.disc, parameter = list(supp = 0.01, conf = 0.2, minlen = 2),
                  appearance = list(default="rhs", lhs="federal_loan_rate=high"),
                  control=list(verbose=F))
summary(rules2) # yields 18 rules
plot(rules2,method="graph", engine='interactive', shading=NA)
rules2.c <- sort(rules2, decreasing = TRUE, by = "confidence")
arules::inspect(rules2.c)
# small school, completion is medium, retention is low med & high, completion low & med

rules2.s <- sort(rules2, decreasing=TRUE, by ="support")
arules::inspect(rules2.s)

rules2.l <- sort(rules2, decreasing=TRUE, by = "lift")
arules::inspect(rules2.l) 
# high lift: retention is low, inclusive, a&s/diverse fields, completion is low

abc <- sample(rules2.l,1)

# additional viz
plot(rules2, method="graph")
plot(abc, method="doubledecker", data="d.disc")


## RHS: Federal loan rate = high
rules3 <- apriori(d.disc, parameter = list(supp = 0.04, conf = 0.8, maxlen = 5),
                  appearance = list(default="lhs", rhs="federal_loan_rate=high"),
                  control=list(verbose=F))
summary(rules3) # yields 103 rules
#viz
plot(rules3,method="graph", engine='interactive', shading=NA)

rules3.c <- sort(rules3, decreasing = TRUE, by = "confidence")
arules::inspect(rules3.c[1:5])
# small school, completion is medium, retention is low med & high, completion low & med

rules3.s <- sort(rules3, decreasing=TRUE, by ="support")
arules::inspect(rules3.s[1:5])

rules3.l <- sort(rules3, decreasing=TRUE, by = "lift")
arules::inspect(rules3.l[1:10]) 
# medium completion
?is.redundant
quality(rules3.l)$improvement <- interestMeasure(rules3.l, measure="improvement")
inspect(rules3.l[!is.redundant(rules3.l)])


## high completion
rules4 <- apriori(d.disc[,-3], parameter=list(supp=.001, conf=.01, minlen=2),
                  appearance=list(default="rhs", lhs="completion_rate_4yr_150nt=high"))
plot(rules4,method="graph", engine='interactive', shading=NA)
summary(rules4)
arules::inspect(rules4)
rules4.c <- sort(rules4, decreasing = TRUE, by = "support")
arules::inspect(rules4.c[1:10])
# completion & retention. pell_grant_rate=low, fed loan rate = med. common
rules4.l <- sort(rules4, decreasing=TRUE, by= "lift")
arules::inspect(rules4.l[1:10])
# fed loan rate = low, pell-grant-rate = low. 


## low completion LHS
rules5 <- apriori(d.disc[,-3], parameter=list(supp=.001, conf=.01, minlen=2),
                  appearance=list(default="rhs", lhs="completion_rate_4yr_150nt=low"))
plot(rules5,method="graph", engine='interactive', shading=NA)
summary(rules5)
arules::inspect(rules5)
rules5.c <- sort(rules5, decreasing = TRUE, by = "support")
arules::inspect(rules5.c[1:10])
# medium pell grant rate. low price & low price. also high fed loans
rules5.l <- sort(rules5, decreasing=TRUE, by= "lift")
arules::inspect(rules5.l[1:10])
# pell-grant-rate = high 

## high retention
rules6 <- apriori(d.disc[,-3], parameter=list(supp=.001, conf=.01, minlen=2),
                  appearance=list(default="rhs", lhs="retention_rate.four_year.full_time=high"))

plot(rules6,method="graph", engine='interactive', shading=NA)

summary(rules6)
arules::inspect(rules6)
rules6.c <- sort(rules6, decreasing = TRUE, by = "support")
arules::inspect(rules6.c[1:10])
# pell grant=low, fed loan = med, avg net price=med, 

rules6.l <- sort(rules6, decreasing=TRUE, by= "lift")
arules::inspect(rules6.l[1:10])
# fed loan rate = low

## low completion LHS
rules7 <- apriori(d.disc[,-3], parameter=list(supp=.001, conf=.01, minlen=2),
                  appearance=list(default="rhs", lhs="retention_rate.four_year.full_time=low"))
plot(rules7,method="graph", engine='interactive', shading=NA)
summary(rules7)
arules::inspect(rules7)
rules7.c <- sort(rules7, decreasing = TRUE, by = "support")
arules::inspect(rules7.c[1:10])
# high fed loan, med pell grant, med/low avg net price

rules7.l <- sort(rules7, decreasing=TRUE, by= "lift")
arules::inspect(rules7.l[1:10])
# high pell grant has highest lift, fedloanrate= high


# high pell grant
rules8 <- apriori(d.disc, parameter = list(supp = 0.01, conf = 0.2, minlen = 2),
                  appearance = list(default="rhs", lhs="pell_grant_rate=high"),
                  control=list(verbose=F))
summary(rules8)
arules::inspect(rules8)
plot(rules8,method="graph", engine='interactive', shading=NA)
rules8.c <- sort(rules8, decreasing = TRUE, by = "confidence")
arules::inspect(rules8.c)
rules8.l <- sort(rules8, decreasing=TRUE, by = "lift")
arules::inspect(rules8.l)

# low pell grant
rules9 <- apriori(d.disc, parameter = list(supp = 0.01, conf = 0.2, minlen = 2),
                  appearance = list(default="rhs", lhs="pell_grant_rate=low"),
                  control=list(verbose=F))
summary(rules9)
arules::inspect(rules9)
plot(rules9,method="graph", engine='interactive', shading=NA)
rules9.c <- sort(rules9, decreasing = TRUE, by = "confidence")
arules::inspect(rules9.c)
rules9.l <- sort(rules9, decreasing=TRUE, by = "lift")
arules::inspect(rules9.l)

# low fed grant
rules10 <- apriori(d.disc, parameter = list(supp = 0.01, conf = 0.2, minlen = 2),
                  appearance = list(default="rhs", lhs="federal_loan_rate=low"),
                  control=list(verbose=F))
summary(rules10)
arules::inspect(rules10)
plot(rules10,method="graph", engine='interactive', shading=NA)
rules10.c <- sort(rules10, decreasing = TRUE, by = "confidence")
arules::inspect(rules10.c)
rules10.l <- sort(rules10, decreasing=TRUE, by = "lift")
arules::inspect(rules10.l)




rm(rules, rules.c, rules.l, rules.s, rules2, rules2.c, rules2.l, rules2.s, rules3, rules3.c, rules3.l, rules3.s, rules4, rules4.c, rules4.l, rules4.s, rules5, rules5.c, rules5.l, rules5.s, rules6, rules6.c, rules6.l, rules6.s, rules7, rules7.c, rules7.l)
rm(rules42, rules8, rules8.c, rules8.l, rules10, rules10.c, rules10.l, rules9, rules9.c, rules9.l)

## Decision tree ----
library(caret)
library(e1071)
library(rpart)
library(rpart.plot)
library(rattle)

         #if clusters are not in during dataframe, use this to add them: 
       during <-scorecard %>%
            select(name, carnegie.basic, carnegie.ugrd, state, size, attendance.academic_year, avg_net_price, pell_grant_rate, federal_loan_rate, retention_rate.four_year.full_time, completion_rate_4yr_150nt)

        distance.euc <- get_dist(during[,5:11], method = "euclidean")
        e.ward <- agnes(distance.euc, method = "ward")
      ewrd.d <- hclust(distance.euc, method="ward.D2")
        sub_grp4 <- cutree(ewrd.d, k=4)
        during <- during %>% mutate(cluster=sub_grp4)
      during$cluster <- ifelse(during$cluster==1, "Entry Level", 
                                ifelse(during$cluster==2, "Stable", 
                                 ifelse(during$cluster==3, "Reachers", 
                                 ifelse(during$cluster==4, "Privileged", "ERROR"))))
         during$cluster <- factor(during$cluster)
        rm(e.ward, ewrd.d)

#Predict retention & completion based on fed & pell rates


# what will our label be? discretized forms of retention & completion?
discretize <- function(var) {
  return(cut(var, breaks=3, labels=c("low", "med", "high")))
}
# create retention dataset
dur.ret <- during %>% select(name, size, attendance.academic_year, avg_net_price, pell_grant_rate, federal_loan_rate, cluster)
dur.ret$retention <- during$retention_rate.four_year.full_time
dur.ret$retention <- discretize(dur.ret$retention)
table(dur.ret$retention)
ret.breaks <- cut(during$retention_rate.four_year.full_time, breaks=3)
table(ret.breaks)

# create completion dataset
dur.comp <- during %>% select(name, size, attendance.academic_year, avg_net_price, pell_grant_rate, federal_loan_rate, cluster)
dur.comp$completion <- during$completion_rate_4yr_150nt
dur.comp$completion <- discretize(dur.comp$completion)
table(dur.comp$completion)
comp.breaks <- cut(during$completion_rate_4yr_150nt, breaks=3)
table(comp.breaks) 

#clean up
rm(ret.breaks, comp.breaks)

# size of training dataset?
nrow(dur.comp)*(2/3) #330

# create training & testing data sets
gen.training <- function(seed, labeled) {
  set.seed(seed)
  trn <- sample_n(labeled, 330)
  return(trn)
}
gen.test <- function(labeled, trn) {
  test <- anti_join(labeled, trn, by = "name")
  test <- test %>% select(-name)
  return(test)
}



# repeat for retention
r.trn1 <- gen.training(12, dur.ret)
r.tst1 <- gen.test(dur.ret, r.trn1)
r.trn1 <- r.trn1 %>% select(-name)
r.tst1.lab <- r.tst1$retention
r.tst1 <- r.tst1 %>% select(-retention)
table(r.trn1$retention)
# repeat for completion
c.trn1 <- gen.training(12, dur.comp)
c.tst1 <- gen.test(dur.comp, c.trn1)
c.trn1 <- c.trn1 %>% select(-name)
table(c.trn1$completion)
c.tst1.lab <- c.tst1$completion
c.tst1 <- c.tst1 %>% select(-completion)

str(c.trn1)
str(c.trn12)


# fit1: retention
rfit1 <- rpart(retention~., data=r.trn1, cp= .0001, method="class")
summary(rfit1)
printcp(rfit1)  # Rel Error/Training error is 62%
1-.37500

predicted1 = predict(rfit1, r.tst1, type="class")
predicted1
confusionMatrix(predicted1, r.tst1.lab) #71.34% accuracy

# try with a higher cp
rfit12 <- rpart(retention~., data=r.trn1, cp= .007, method="class")
printcp(rfit12)
1-.38509 #61.49%
#test
predicted12 = predict(rfit12, r.tst1, type="class")
predicted12
confusionMatrix(predicted12, r.tst1.lab) #71.95% accuracy

fancyRpartPlot(rfit12)

# information gain ratio
GR <- CORElearn::attrEval(r.trn1$retention ~ ., data = r.trn1, estimator = "GainRatio")
GR <- sort(desc(GR))
GR

# modify formula
rfit2 <- rpart(retention~attendance.academic_year+federal_loan_rate+size+pell_grant_rate, data=r.trn1, cp=.02, method="class")
summary(rfit2)
printcp(rfit2) #
1-.40994 # training error is 59%

predicted2 <- predict(rfit2, r.tst1, type="class")
confusionMatrix(predicted2, r.tst1.lab) #75%
fancyRpartPlot(rfit2)
# if pell grant rate is low and the school is big, then high retention. if school is small then medium retention
# if pell rate is high and school is very small, low retention. if it's a big school then higher retention, and medium it's medium.

# Information gain
IG <- CORElearn::attrEval(r.trn1$retention ~ ., data = r.trn1, estimator = "InfGain")
IG <- sort(desc(IG))
IG

rfit3 <- rpart(retention~cluster+pell_grant_rate+attendance.academic_year + size, data=r.trn1, cp=.02, method="class")
summary(rfit3)
printcp(rfit3)
1-.40994 #59%
predicted3 <- predict(rfit3, r.tst1, type="class")
confusionMatrix(predicted3, r.tst1.lab)
fancyRpartPlot(rfit3)


# fit2: completion
cfit1 <- rpart(completion~., data=c.trn1,cp=.006, method="class")
summary(cfit1)
printcp(cfit1)
1-.4303 #56.97%
c.predicted1 = predict(cfit1, c.tst1, type="class")
confusionMatrix(c.predicted1, c.tst1.lab) #69.51% accuracy

fancyRpartPlot(cfit1)

# information gain ratio
GR <- CORElearn::attrEval(c.trn1$completion ~ ., data = c.trn1, estimator = "GainRatio")
GR <- sort(desc(GR))
GR

# modify fit2
cfit2 <- rpart(completion~attendance.academic_year + avg_net_price + pell_grant_rate, data=c.trn1, cp=.02, method="class")
summary(cfit2)
printcp(cfit2)
1-.5030 #49.7%
c.predicted2 = predict(cfit2, c.tst1, type="class")
confusionMatrix(c.predicted2, c.tst1.lab)  # 72% accuracy
fancyRpartPlot(cfit2)
# if pell grants are low, then high completion. if they're high then low. if they're btwn 23-25, then it depends on cost peryear. if it's less than $17k then low. if greater then medium

# Information gain
IG <- CORElearn::attrEval(c.trn1$completion ~ ., data = c.trn1, estimator = "InfGain")
IG <- sort(desc(IG))
IG

# modify fit3
cfit3 <- rpart(completion~cluster+pell_grant_rate+attendance.academic_year, data=c.trn1, cp=.02, method="class")
summary(cfit3)
printcp(cfit3)
1-.47879 #52.2%
c.predicted3 = predict(cfit3, c.tst1, type="class")
confusionMatrix(c.predicted3, c.tst1.lab)  # 73.78% accuracy
fancyRpartPlot(cfit3)





#rm(c.tst1, cfit1, c.trn1, r.trn1, r.tst1, rfit1, dur.comp, dur.ret)


## Text mining ----
library(tm)
library(wordcloud)
library(stringr)
library(slam)
library(snowballC)
# load in articles about college scorecard
sc.corpus <- Corpus(DirSource("Text.mining"))
length(sc.corpus)
summary(sc.corpus)
meta(sc.corpus[[1]])

# clean up corpus
sc.corpus <- tm_map(sc.corpus, content_transformer(tolower))
sc.corpus <- tm_map(sc.corpus, removeNumbers)
sc.corpus <- tm_map(sc.corpus, removeWords, stopwords("english"))
sc.corpus <- tm_map(sc.corpus, removePunctuation)
sc.corpus <- tm_map(sc.corpus, stripWhitespace)
sc.corpus <- tm_map(sc.corpus, stemDocument)

# create a term-document matrix
tdm <- TermDocumentMatrix(sc.corpus)
tdm$dimnames
str(tdm)
m <- as.matrix(tdm)
m
v <- sort(rowSums(m), decreasing=TRUE)
head(v, 100)

#identify some words that don't add much meaning. create new stop word list and regenerate tdm
mystopwords <- c("said", "use", "one", "will", "get", "like", "call", "can", "say", "much", "just", "two")
sc.corpus <- tm_map(sc.corpus, removeWords, mystopwords)

# new tdm
tdm <- TermDocumentMatrix(sc.corpus)
m<- as.matrix(tdm)
v<-sort(rowSums(m), decreasing=TRUE)
head(v, 100)
d <- data.frame(word=names(v), freq=v)

# create wordcloud
wordcloud(words=d$word, fre=d$freq, max.words=75, colors=brewer.pal(8, "Dark2"))
# rm(sc.corpus, tdm, m, v, mystopwords)
